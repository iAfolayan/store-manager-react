const { API_BASE_URL } = process.env;
const signin = 'sign';
const authentication = 'authentication';
const networkErrorResponse = 'Network error! kindly try again later';

export { API_BASE_URL, signin, authentication, networkErrorResponse };
