import React, { Component } from 'react';
import './User.css'
import Navigation from '../common/Navigation';
import InputForm from '../InputForms/InputForm';
import { formatResultsErrors } from 'jest-message-util';

class User extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: {
        staffId: '',
        title: '',
        phoneNumber:'',
        emailAddress:'',
        fullname:'',
      },
      isLoading: false,
      errors: {}
    }
  }

  handleChange = event => {
    const { user } = this.state;
    const { name, value } = event.target;
    user[name] = value;
    this.setState({
      user
    });
  }

  handleSubmit = () => {
    console.log('Submitted');
  }
  render() {
    const { user, errors } = this.state;
    return (
            <div className="formWrapper">
              <form onSubmit={this.handleSubmit}>
                <InputForm
                  error={errors.title}
                  text="Title"
                  label="title"
                  type="text"
                  name="title"
                  id="title"
                  className="col-md-6"
                  value={title}
                  placeholder="Enter staff title (Miss,Mrs,Mr.)"
                  onChange={this.handleChange}
                />
                <InputForm
                  text="Fullname"
                  label="fName"
                  type="text"
                  name="fName"
                  id="fName"
                  value={fullname}
                  placeholder="Enter staff fullname (surname first)"
                  onChange={this.handleChange}
                />
                <InputForm
                  text="StaffId"
                  label="StaffId"
                  type="text"
                  name="staffId"
                  id="StaffId"
                  value={staffId}
                  placeholder="Enter staff Id"
                  onChange={this.handleChange}
                />
                <InputForm
                  text="Phone Number"
                  label="phoneNumber"
                  type="number"
                  name="phoneNumber"
                  id="phoneNumber"
                  value={phoneNumber}
                  placeholder="Enter phone Number"
                  onChange={this.handleChange}
                />
                <InputForm
                  text="Email Address"
                  label="email"
                  type="email"
                  name="email"
                  id="email"
                  value={emailAddress}
                  placeholder="Enter staff emailAddress"
                  onChange={this.handleChange}
                />
                <button className="btn btn-outline-primary float-right">Submit</button>
              </form>
            </div>
    );
  }
}

export default User;