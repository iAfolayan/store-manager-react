const triggerLoading = type => ({
  type
});

export default triggerLoading;
